Bước 1: build file đáp án ra file .exe (FNHOUSES.cpp -> FNHOUSES.exe)
Bước 2: tạo folder test
Bước 3: run file gen.cpp